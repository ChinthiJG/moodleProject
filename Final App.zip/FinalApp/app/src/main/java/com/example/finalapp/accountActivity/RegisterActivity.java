package com.example.finalapp.accountActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalapp.MainActivity;
import com.example.finalapp.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private EditText studentId,firstName,surname,email,password,confirmPassword;
    private Button register;
    private TextView viewTC;
    private CheckBox readTick;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        databaseReference = FirebaseDatabase.getInstance().getReference("Students");
        studentId = (EditText)findViewById(R.id.id);
        firstName = (EditText)findViewById(R.id.first_name);
        surname = (EditText)findViewById(R.id.surname);
        email= (EditText)findViewById(R.id.email);
        password = (EditText)findViewById(R.id.password);
        confirmPassword = (EditText)findViewById(R.id.confirm_password);
        register = (Button) findViewById(R.id.register);
        readTick = (CheckBox)findViewById(R.id.checked);
        viewTC = (TextView)findViewById(R.id.tc);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addStudents();
            }
        });

        viewTC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });


    }

    public void openActivity3(){
        Intent intent = new Intent(this,TCActivity.class);
        startActivity(intent);
    }



    public void addStudents(){

        String studentID = studentId.getText().toString();
        String studentFirstName = firstName.getText().toString();
        String studentSurname = surname.getText().toString();
        String studentEmail = email.getText().toString();
        String studentPassword = password.getText().toString();
        String studentConfirmPassword = confirmPassword.getText().toString();

        if (!TextUtils.isEmpty(studentID) && !TextUtils.isEmpty(studentConfirmPassword) && !TextUtils.isEmpty(studentPassword) && !TextUtils.isEmpty(studentEmail) && !TextUtils.isEmpty(studentSurname) && !TextUtils.isEmpty(studentFirstName) ){
            if ((studentConfirmPassword).equals(studentPassword)){
                if (readTick.isChecked()){
                    String id = databaseReference.push().getKey();
                    Student student = new Student(studentID,studentFirstName,studentSurname,studentEmail,studentPassword);
                    databaseReference.child(studentID).setValue(student);
                    studentId.setText("");
                    firstName.setText("");
                    surname.setText("");
                    email.setText("");
                    password.setText("");
                    confirmPassword.setText("");
                    Toast.makeText(RegisterActivity.this,"Registration Successful",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(RegisterActivity.this,"Please read terms and conditions",Toast.LENGTH_LONG).show();
                }


            }else {
                Toast.makeText(RegisterActivity.this,"Password and confirm password not match",Toast.LENGTH_LONG).show();
            }

        }else{
            Toast.makeText(RegisterActivity.this,"Complete the details",Toast.LENGTH_LONG).show();
        }

    }

}
