package com.example.finalapp.library;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.finalapp.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ViewDatabase extends ArrayAdapter<Book> {

    private static final String Tag = "ViewDatabase";
    private Context mcontext;
    int mResourse;

    public ViewDatabase(@NonNull Context context, int resourse, @NonNull List<Book> objects){
        super(context,resourse,objects);
        this.mcontext=context;
        mResourse = resourse;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String name = getItem(position).getName();
        String publisher = getItem(position).getPublisher();
        String language = getItem(position).getLanguage();
        String Isbn = getItem(position).getISBN();
        String dimension = getItem(position).getDimension();
        String author = getItem(position).getAuthor();
        String url = getItem(position).getUrl();

        Book book = new Book(name,publisher,language,Isbn,dimension,author,url);

        LayoutInflater inflater = LayoutInflater.from(mcontext);
        convertView = inflater.inflate(mResourse,parent,false);

        TextView txt = (TextView)convertView.findViewById(R.id.userInfo);


        txt.setText(name);



        return convertView;







    }
}
