package com.example.finalapp.applicationActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.finalapp.R;

public class FloorMapsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_floor_maps);
    }
}
