package com.example.finalapp.library;

import java.io.Serializable;

public class Book implements Serializable {

    private String name;
    private String publisher;
    private String language;
    private String ISBN;
    private String dimension;
    private String author;
    private String url;

    public Book() {
    }

    public Book(String book_name, String publisher, String language, String ISBN, String dimension, String author, String url) {
        this.name = book_name;
        this.publisher = publisher;
        this.language = language;
        this.ISBN = ISBN;
        this.dimension = dimension;
        this.author = author;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
