package com.example.finalapp.bookSale;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.finalapp.R;

public class BookSaleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_sale);
    }
}
