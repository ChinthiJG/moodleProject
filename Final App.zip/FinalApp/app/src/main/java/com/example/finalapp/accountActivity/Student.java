package com.example.finalapp.accountActivity;

public class Student {
    private String studentID ;
    private String studentFirstName ;
    private String studentSurname ;
    private String studentEmail ;
    private String studentPassword ;


    public Student() {

    }
    public Student(String studentID, String studentFirstName, String studentSurname, String studentEmail, String studentPassword) {
        this.studentID = studentID;
        this.studentFirstName = studentFirstName;
        this.studentSurname = studentSurname;
        this.studentEmail = studentEmail;
        this.studentPassword = studentPassword;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getStudentFirstName() {
        return studentFirstName;
    }

    public void setStudentFirstName(String studentFirstName) {
        this.studentFirstName = studentFirstName;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public void setStudentSurname(String studentSurname) {
        this.studentSurname = studentSurname;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        this.studentPassword = studentPassword;
    }


}
