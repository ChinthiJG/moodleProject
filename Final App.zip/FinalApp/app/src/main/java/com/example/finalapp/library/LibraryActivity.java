package com.example.finalapp.library;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class LibraryActivity extends AppCompatActivity {
    EditText search;
    ListView listView;
    TextView cat1,cat2,cat3,cat4;
    DatabaseReference database,ref,ref1;
    ArrayList<Book> list;
    Book book;
    ViewDatabase adapter;
    ArrayAdapter adapter1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);


        listView = (ListView)findViewById(R.id.listView);
        cat1 = (TextView)findViewById(R.id.txt1);
        cat2 = (TextView)findViewById(R.id.txt2);
        cat3 = (TextView)findViewById(R.id.txt3);
        cat4 = (TextView)findViewById(R.id.txt4);
        search = (EditText) findViewById(R.id.inputSearch);

        cat1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Category01();

            }
        });

        cat2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Category02();
            }
        });

        cat3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Category03();
            }
        });

        cat4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Category04();
            }
        });





        //ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this);
        //viewPager.setAdapter(viewPagerAdapter);


        //Category01();
////////////////////////////////////////////////////////////////////////////


    }

    public void Category01(){


        list = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference();
        ref = database.child("Category").child("Category 01").getRef();
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list.clear();
                for(DataSnapshot ds:dataSnapshot.getChildren()){

                    Book book = ds.getValue(Book.class);
                    list.add(book);

                }
                adapter = new ViewDatabase(LibraryActivity.this,R.layout.user_info,list);
                listView.setAdapter(adapter);

                bookDetails();



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void Category02() {


        list = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference();
        ref = database.child("Category").child("Category 02").getRef();
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    list.clear();
                    Book book = ds.getValue(Book.class);
                    list.add(book);

                }
                final ViewDatabase adapter = new ViewDatabase(LibraryActivity.this, R.layout.user_info, list);
                listView.setAdapter(adapter);
                bookDetails();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void Category03() {


        list = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference();
        ref = database.child("Category").child("Category 03").getRef();
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    list.clear();
                    Book book = ds.getValue(Book.class);
                    list.add(book);

                }
                final ViewDatabase adapter = new ViewDatabase(LibraryActivity.this, R.layout.user_info, list);
                listView.setAdapter(adapter);
                bookDetails();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void Category04() {


        list = new ArrayList<>();
        database = FirebaseDatabase.getInstance().getReference();
        ref = database.child("Category").child("Category 04").getRef();
        ref.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    list.clear();
                    Book book = ds.getValue(Book.class);
                    list.add(book);

                }
                final ViewDatabase adapter = new ViewDatabase(LibraryActivity.this, R.layout.user_info, list);
                listView.setAdapter(adapter);
                bookDetails();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void bookDetails(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book b = list.get(position);

                Bundle bundle = new Bundle();
                bundle.putSerializable("Book",b);

                Intent intent = new Intent(LibraryActivity.this,BookDetailsActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

}
