package com.example.finalapp.accountActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.example.finalapp.MainActivity;
import com.example.finalapp.R;
import com.example.finalapp.applicationActivity.MoodlePageLoadActivity;
import com.example.finalapp.library.LibraryActivity;

public class HomeActivity extends AppCompatActivity {
    private TextView MPLink;
    private Button btnHome;
    private Button btnTB;
    private Button btnMF;
    private Button btnBS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        MPLink = (TextView) findViewById(R.id.moodle_page_link);
        MPLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,MoodlePageLoadActivity.class);
                startActivity(intent);
            }
        });
        btnHome = (Button)findViewById(R.id.btn_library);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, LibraryActivity.class);
                startActivity(intent);
            }
        });
    }
}
