package com.example.finalapp.library;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.finalapp.R;

public class BookDetailsActivity extends AppCompatActivity {

    TextView isbn,author,dimension,language,name,publisher;
    ImageView imageView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);

        isbn = (TextView)findViewById(R.id.ISBN);
        author = (TextView)findViewById(R.id.author);
        dimension = (TextView)findViewById(R.id.dimension);
        language = (TextView)findViewById(R.id.language);
        name = (TextView)findViewById(R.id.name);
        publisher = (TextView)findViewById(R.id.publisher);

        Bundle bundle =getIntent().getExtras();
        Book b = (Book) bundle.getSerializable("Book");
        isbn.setText(b.getISBN());
        author.setText(b.getAuthor());
        dimension.setText(b.getDimension());
        language.setText(b.getLanguage());
        name.setText(b.getName());
        publisher.setText(b.getPublisher());



    }
}
