package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalapp.accountActivity.HomeActivity;
import com.example.finalapp.accountActivity.RegisterActivity;
import com.example.finalapp.accountActivity.Student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    int count;
    private Button button;
    private TextView txt1,txt2;
    private EditText x,y;
    DatabaseReference databaseReference,mRef;
    Student student;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.login);
        txt1 = (TextView) findViewById(R.id.new_register);
        txt2 = (TextView) findViewById(R.id.forgot_password);

        x = (EditText) findViewById(R.id.id);


        y = (EditText) findViewById(R.id.password);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        mRef = databaseReference.child("Students").getRef();


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mRef.addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String xxx = x.getText().toString();
                        String yyy = y.getText().toString();
                        try{
                            for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                                String data1 = dataSnapshot.child(xxx).child("studentPassword").getValue().toString();
                                if(yyy.equals(data1)){
                                    Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                                    startActivity(intent);


                                }
                                else{
                                    Toast.makeText(MainActivity.this,"Login Fail",Toast.LENGTH_LONG).show();
                                }
                            }
                        }catch(Exception ex){
                            Toast.makeText(MainActivity.this,"Login Fail",Toast.LENGTH_LONG).show();
                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });

        txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });

    }

    public void openActivity2(){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

}
