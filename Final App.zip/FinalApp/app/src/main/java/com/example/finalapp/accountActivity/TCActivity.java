package com.example.finalapp.accountActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.finalapp.R;

public class TCActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t_c);
    }
}
